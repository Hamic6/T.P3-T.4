﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercice_e
{
    class Program
    {
        static void Main(string[] args)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            int i, c = 0;
            for (i = 0; i < 1000000000; i++)
            {
                c++;
            }
            stopwatch.Stop();
            Console.Write("Temps d'execution:");
            Console.WriteLine(stopwatch.ElapsedMilliseconds);
            Console.Read();
        }
    }
}
