﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercice_d
{
    class Program
    {
        static void Main(string[] args)
        {

            PerformanceCounter cpuFrequence;
            cpuFrequence = new PerformanceCounter();
            cpuFrequence.CategoryName = "Processor Information";
            cpuFrequence.CounterName = "Processor Frequency";
            cpuFrequence.InstanceName = "0,0";
            Console.Write("Frequency of processor 0 is:");
            Console.WriteLine(cpuFrequence.NextValue());

        }
    }
}